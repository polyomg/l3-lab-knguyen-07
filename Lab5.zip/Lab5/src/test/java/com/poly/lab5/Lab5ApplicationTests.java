package com.poly.lab5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab5ApplicationTests {

    @Test
    void contextLoads() {
    }

}
